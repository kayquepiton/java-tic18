package Semana4;

public class Postagem {
    private Usuario autor;
    private String conteudo;

    public Postagem(Usuario autor, String conteudo) {
        this.autor = autor;
        this.conteudo = conteudo;
    }
}

